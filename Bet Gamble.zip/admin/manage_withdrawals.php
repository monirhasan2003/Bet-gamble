<?php
require_once 'admin_header.php';

$error_message = '';
$success_message = '';

// Handle approve/reject actions... (this logic is the same)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['approve_withdrawal'])) {
        $transaction_id = intval($_POST['transaction_id']);
        $stmt = $conn->prepare("UPDATE transactions SET status = 'completed' WHERE transaction_id = ? AND status = 'pending'");
        $stmt->execute([$transaction_id]);
        $success_message = "Withdrawal request approved.";
    }
    if (isset($_POST['reject_withdrawal'])) {
        $transaction_id = intval($_POST['transaction_id']);
        $user_id_to_refund = intval($_POST['user_id']);
        $amount_to_refund = floatval($_POST['amount']);
        $conn->beginTransaction();
        try {
            $reject_stmt = $conn->prepare("UPDATE transactions SET status = 'rejected' WHERE transaction_id = ? AND status = 'pending'");
            $reject_stmt->execute([$transaction_id]);
            $refund_stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE user_id = ?");
            $refund_stmt->execute([$amount_to_refund, $user_id_to_refund]);
            $conn->commit();
            $success_message = "Withdrawal rejected and refunded.";
        } catch (Exception $e) {
            $conn->rollBack();
            $error_message = "An error occurred: " . $e->getMessage();
        }
    }
}

// Fetch all pending withdrawal requests
$withdrawals_stmt = $conn->query("
    SELECT t.*, u.username 
    FROM transactions AS t
    JOIN users AS u ON t.user_id = u.user_id
    WHERE t.type = 'withdrawal' AND t.status = 'pending'
    ORDER BY t.created_at ASC
");
$pending_withdrawals = $withdrawals_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="form-container !max-w-6xl">
    <h2 class="text-2xl font-bold mb-6">Pending Withdrawal Requests</h2>
    
    <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
    <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>

    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Date</th>
                    <th class="p-4">User</th>
                    <th class="p-4">Method & Details</th> <!-- UPDATED COLUMN -->
                    <th class="p-4 text-right">Amount</th>
                    <th class="p-4 text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pending_withdrawals)): ?>
                    <tr><td colspan="5" class="p-8 text-center text-gray-400">There are no pending withdrawal requests.</td></tr>
                <?php else: ?>
                    <?php foreach ($pending_withdrawals as $withdrawal): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 text-gray-300"><?php echo date("M j, Y, g:i a", strtotime($withdrawal['created_at'])); ?></td>
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($withdrawal['username']); ?></td>
                            <!-- NEW: Display the structured details -->
                            <td class="p-4 text-sm text-gray-300">
                                <strong class="text-white"><?php echo ucfirst($withdrawal['payment_method']); ?>:</strong><br>
                                <div class="pl-2 border-l-2 border-gray-700 mt-1 font-mono text-xs">
                                <?php
                                    $details = json_decode($withdrawal['withdrawal_details'], true);
                                    if (is_array($details)) {
                                        foreach ($details as $key => $value) {
                                            echo '<strong>' . htmlspecialchars(ucfirst(str_replace('_', ' ', $key))) . ':</strong> ' . htmlspecialchars($value) . '<br>';
                                        }
                                    } else {
                                        echo htmlspecialchars($withdrawal['withdrawal_details']); // Fallback for old data
                                    }
                                ?>
                                </div>
                            </td>
                            <td class="p-4 text-right font-mono text-red-400">$<?php echo number_format($withdrawal['amount'], 2); ?></td>
                            <td class="p-4 flex items-center justify-center space-x-2">
                                <form action="manage_withdrawals.php" method="post" onsubmit="return confirm('Have you sent the funds? This marks the request as complete.');">
                                    <input type="hidden" name="transaction_id" value="<?php echo $withdrawal['transaction_id']; ?>">
                                    <button type="submit" name="approve_withdrawal" class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">Approve</button>
                                </form>
                                <form action="manage_withdrawals.php" method="post" onsubmit="return confirm('Are you sure you want to reject this request and refund the money?');">
                                    <input type="hidden" name="transaction_id" value="<?php echo $withdrawal['transaction_id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $withdrawal['user_id']; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $withdrawal['amount']; ?>">
                                    <button type="submit" name="reject_withdrawal" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
