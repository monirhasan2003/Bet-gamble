<?php
require_once 'admin_header.php';

// --- DATA FETCHING ---
// Get all transactions from the database, joining with the users table to get the username
// Ordering by the most recent first.
$transactions_stmt = $conn->query("
    SELECT t.*, u.username
    FROM transactions AS t
    JOIN users AS u ON t.user_id = u.user_id
    ORDER BY t.created_at DESC
");
$all_transactions = $transactions_stmt->fetchAll(PDO::FETCH_ASSOC);
// --- END OF DATA FETCHING ---
?>

<div class="form-container !max-w-6xl">
    <h2 class="text-2xl font-bold mb-6">Global Transaction Log</h2>
    <p class="text-lg text-gray-300 mb-6">A complete record of all financial activity across the platform.</p>

    <!-- Table to display all transactions -->
    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Date</th>
                    <th class="p-4">User</th>
                    <th class="p-4">Type</th>
                    <th class="p-4 text-right">Amount</th>
                    <th class="p-4">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($all_transactions)): ?>
                    <tr><td colspan="5" class="p-8 text-center text-gray-400">No transactions have been recorded yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($all_transactions as $trans): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 text-gray-300 text-sm"><?php echo date("M j, Y, g:i a", strtotime($trans['created_at'])); ?></td>
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($trans['username']); ?></td>
                            <td class="p-4 text-sm font-medium text-gray-300">
                                <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $trans['type']))); ?>
                            </td>
                            <?php
                                // Set color based on transaction type
                                $amount_class = 'text-gray-300'; // Default
                                $amount_prefix = '';
                                if (in_array($trans['type'], ['deposit', 'bet_win', 'bonus'])) {
                                    $amount_class = 'text-green-400 font-semibold';
                                    $amount_prefix = '+';
                                } elseif (in_array($trans['type'], ['withdrawal', 'bet_placement'])) {
                                    $amount_class = 'text-red-400 font-semibold';
                                    $amount_prefix = '-';
                                }
                            ?>
                            <td class="p-4 text-right font-mono <?php echo $amount_class; ?>">
                                <?php echo $amount_prefix; ?>$<?php echo number_format($trans['amount'], 2); ?>
                            </td>
                            <td class="p-4 text-sm">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php 
                                        if ($trans['status'] == 'completed') echo 'bg-green-100 text-green-800';
                                        elseif ($trans['status'] == 'pending') echo 'bg-yellow-100 text-yellow-800';
                                        else echo 'bg-red-100 text-red-800';
                                    ?>">
                                    <?php echo htmlspecialchars(ucfirst($trans['status'])); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
