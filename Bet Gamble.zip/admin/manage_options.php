<?php
require_once 'admin_header.php';

if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    die("Error: Invalid Event ID.");
}
$event_id = intval($_GET['event_id']);

$error_message = '';
$success_message = '';

// --- LOGIC TO SET A WINNER ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['set_winner'])) {
    $winning_option_id = intval($_POST['winning_option_id']);

    // Double-check that this event is still 'open' before settling
    $event_check_stmt = $conn->prepare("SELECT status FROM bet_events WHERE event_id = ?");
    $event_check_stmt->execute([$event_id]);
    $event_status = $event_check_stmt->fetchColumn();

    if ($event_status !== 'open') {
        $error_message = "This event has already been settled or cancelled.";
    } else {
        // Use a transaction for safety. All steps must succeed or none will.
        $conn->beginTransaction();
        try {
            // 1. Update the main event to mark it as settled
            $update_event_stmt = $conn->prepare("UPDATE bet_events SET status = 'settled', winning_option_id = ? WHERE event_id = ?");
            $update_event_stmt->execute([$winning_option_id, $event_id]);

            // 2. Find all winning bets
            $winners_stmt = $conn->prepare("SELECT bet_id, user_id, potential_payout FROM user_bets WHERE event_id = ? AND option_id = ? AND status = 'running'");
            $winners_stmt->execute([$event_id, $winning_option_id]);
            $winners = $winners_stmt->fetchAll(PDO::FETCH_ASSOC);

            // 3. Pay out each winner
            foreach ($winners as $winner) {
                // Add winnings to user's wallet
                $payout_stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE user_id = ?");
                $payout_stmt->execute([$winner['potential_payout'], $winner['user_id']]);

                // Create a transaction record for the win
                $trans_stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, related_bet_id, status) VALUES (?, 'bet_win', ?, ?, 'completed')");
                $trans_stmt->execute([$winner['user_id'], $winner['potential_payout'], $winner['bet_id']]);
            }

            // 4. Update the status of all bets for this event
            // Mark winning bets as 'won'
            $update_winners_stmt = $conn->prepare("UPDATE user_bets SET status = 'won' WHERE event_id = ? AND option_id = ?");
            $update_winners_stmt->execute([$event_id, $winning_option_id]);

            // Mark all other bets (the losers) as 'lost'
            $update_losers_stmt = $conn->prepare("UPDATE user_bets SET status = 'lost' WHERE event_id = ? AND option_id != ?");
            $update_losers_stmt->execute([$event_id, $winning_option_id]);

            // If we got here without errors, commit all changes
            $conn->commit();
            $success_message = "Event settled successfully! " . count($winners) . " winner(s) have been paid.";

        } catch (Exception $e) {
            // If any step failed, undo everything
            $conn->rollBack();
            $error_message = "A critical error occurred during settlement. The process has been reversed. Error: " . $e->getMessage();
        }
    }
}

// --- (The rest of the file is for displaying the page) ---

// Handle adding a new option (this code is from before)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_option'])) {
    $option_name = trim($_POST['option_name']);
    $payout_multiplier = trim($_POST['payout_multiplier']);
    if (empty($option_name) || !is_numeric($payout_multiplier)) {
        $error_message = "Option name and a numeric payout are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO bet_options (event_id, option_name, payout_multiplier) VALUES (:event_id, :option_name, :payout_multiplier)");
        $stmt->execute(['event_id' => $event_id, 'option_name' => $option_name, 'payout_multiplier' => $payout_multiplier]);
        $success_message = "Option '$option_name' added successfully!";
    }
}

// Fetch event details
$event_stmt = $conn->prepare("SELECT * FROM bet_events WHERE event_id = ?");
$event_stmt->execute([$event_id]);
$event = $event_stmt->fetch(PDO::FETCH_ASSOC);
if (!$event) { die("Error: Event not found."); }

// Fetch options for this event
$options_stmt = $conn->prepare("SELECT * FROM bet_options WHERE event_id = ? ORDER BY option_id ASC");
$options_stmt->execute([$event_id]);
$options = $options_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="form-container !max-w-4xl">
    <a href="manage_events_v2.php" class="text-yellow-400 hover:underline mb-4 inline-block">&larr; Back to All Events</a>
    <h2 class="text-2xl font-bold">Manage Options For:</h2>
    <p class="text-xl text-gray-300 mb-6 p-4 bg-gray-900/50 rounded-lg">"<?php echo htmlspecialchars($event['question']); ?>"</p>

    <?php if ($event['status'] == 'open'): ?>
        <!-- Form to add a new option -->
        <form action="manage_options.php?event_id=<?php echo $event_id; ?>" method="post" class="mb-10 p-6 bg-gray-900/50 rounded-lg">
            <h3 class="text-xl font-semibold mb-4">Add New Option</h3>
            <?php if(!empty($error_message) && isset($_POST['add_option'])): ?>
                <div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if(!empty($success_message) && isset($_POST['add_option'])): ?>
                <div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div>
            <?php endif; ?>
            <div class="flex items-end space-x-4">
                <div class="flex-grow">
                    <label for="option_name" class="block mb-2 text-sm font-medium text-gray-300">Option Name</label>
                    <input type="text" name="option_name" id="option_name" class="form-input" placeholder="e.g., Yes / No / Team Name" required>
                </div>
                <div>
                    <label for="payout_multiplier" class="block mb-2 text-sm font-medium text-gray-300">Payout (e.g., 1.85)</label>
                    <input type="text" name="payout_multiplier" id="payout_multiplier" class="form-input" placeholder="e.g. 1.85" required>
                </div>
                <button type="submit" name="add_option" class="btn-gradient !w-auto px-8 h-[49px]">Add Option</button>
            </div>
        </form>
    <?php endif; ?>

    <!-- Table to display existing options -->
    <h3 class="text-xl font-semibold mb-4">Existing Options</h3>
    <?php if(!empty($error_message) && isset($_POST['set_winner'])): ?>
        <div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <?php if(!empty($success_message) && isset($_POST['set_winner'])): ?>
        <div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Option Name</th>
                    <th class="p-4">Payout Multiplier</th>
                    <th class="p-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($options)): ?>
                    <tr><td colspan="3" class="p-4 text-center text-gray-400">No options found.</td></tr>
                <?php else: ?>
                    <?php foreach ($options as $option): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($option['option_name']); ?></td>
                            <td class="p-4"><?php echo htmlspecialchars($option['payout_multiplier']); ?>x</td>
                            <td class="p-4 text-right">
                                <?php if ($event['status'] == 'open'): ?>
                                    <form action="manage_options.php?event_id=<?php echo $event_id; ?>" method="post" onsubmit="return confirm('Are you sure? This will settle the event and pay winners. This action cannot be undone.');">
                                        <input type="hidden" name="winning_option_id" value="<?php echo $option['option_id']; ?>">
                                        <button type="submit" name="set_winner" class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">
                                            Set as Winner
                                        </button>
                                    </form>
                                <?php elseif ($event['winning_option_id'] == $option['option_id']): ?>
                                    <span class="bg-yellow-400 text-gray-900 font-bold py-2 px-4 rounded">WINNER</span>
                                <?php else: ?>
                                    <span class="text-gray-500">--</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>