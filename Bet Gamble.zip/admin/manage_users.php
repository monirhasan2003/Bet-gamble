<?php
require_once 'admin_header.php';

$error_message = '';
$success_message = '';

// Handle form submission to create the new user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $initial_balance = floatval($_POST['initial_balance']);

    // Basic validation
    if (empty($username) || empty($email) || empty($password)) {
        $error_message = "Username, Email, and Password are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        try {
            // Check if username or email already exists
            $check_stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $check_stmt->execute([$username, $email]);
            if ($check_stmt->rowCount() > 0) {
                $error_message = "Username or email already exists.";
            } else {
                // Hash the password for security
                $password_hash = password_hash($password, PASSWORD_BCRYPT);

                // Insert the new user into the database
                $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, wallet_balance) VALUES (?, ?, ?, ?)");
                $insert_stmt->execute([$username, $email, $password_hash, $initial_balance]);
                
                $success_message = "User '$username' created successfully!";
            }
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div class="form-container !max-w-4xl">
    <a href="manage_users.php" class="text-yellow-400 hover:underline mb-4 inline-block">&larr; Back to User List</a>
    <h2 class="text-2xl font-bold mb-6">Create New User</h2>

    <!-- Form to create a new user -->
    <form action="create_user.php" method="post" class="p-6 bg-gray-900/50 rounded-lg">
        <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
        <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>

        <div class="space-y-4">
            <div>
                <label for="username" class="block mb-2 text-sm font-medium text-gray-300">Username</label>
                <input type="text" name="username" id="username" class="form-input" required>
            </div>
            <div>
                <label for="email" class="block mb-2 text-sm font-medium text-gray-300">Email Address</label>
                <input type="email" name="email" id="email" class="form-input" required>
            </div>
            <div>
                <label for="password" class="block mb-2 text-sm font-medium text-gray-300">Password</label>
                <input type="text" name="password" id="password" class="form-input" required>
                <p class="text-xs text-gray-400 mt-1">The user can change this after they log in.</p>
            </div>
            <div>
                <label for="initial_balance" class="block mb-2 text-sm font-medium text-gray-300">Initial Wallet Balance ($)</label>
                <input type="text" name="initial_balance" id="initial_balance" class="form-input" value="0.00">
            </div>
            <button type="submit" name="create_user" class="btn-gradient !w-auto px-8">Create User Account</button>
        </div>
    </form>
</div>

</body>
</html>
