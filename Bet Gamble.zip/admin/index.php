<?php
// The header file handles all session checks and security.
require_once 'admin_header.php';

// --- NEW: FETCH PLATFORM STATISTICS ---

// 1. Get Total Deposits
$total_deposits_stmt = $conn->query("SELECT SUM(amount) FROM transactions WHERE type = 'deposit' AND status = 'completed'");
$total_deposits = $total_deposits_stmt->fetchColumn() ?: 0;

// 2. Get Total User Balances (Total money currently in the system)
$total_balance_stmt = $conn->query("SELECT SUM(wallet_balance) FROM users");
$total_user_balances = $total_balance_stmt->fetchColumn() ?: 0;

// 3. Get Total Withdrawals
$total_withdrawals_stmt = $conn->query("SELECT SUM(amount) FROM transactions WHERE type = 'withdrawal' AND status = 'completed'");
$total_withdrawals = $total_withdrawals_stmt->fetchColumn() ?: 0;

// 4. Get Top 3 Earning Traders
$top_traders_stmt = $conn->query("
    SELECT u.username, SUM(t.amount) as total_winnings
    FROM transactions AS t
    JOIN users AS u ON t.user_id = u.user_id
    WHERE t.type = 'bet_win'
    GROUP BY t.user_id
    ORDER BY total_winnings DESC
    LIMIT 3
");
$top_traders = $top_traders_stmt->fetchAll(PDO::FETCH_ASSOC);

// --- END OF STATISTICS FETCHING ---
?>

<div class="form-container !max-w-6xl">
    <h2 class="text-2xl font-bold mb-6">Admin Dashboard</h2>
    
    <!-- NEW: Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Total Deposits Card -->
        <div class="p-6 bg-green-800/50 rounded-lg">
            <h3 class="text-sm font-medium text-green-300 uppercase">Total Deposits</h3>
            <p class="mt-2 text-3xl font-bold text-white">$<?php echo number_format($total_deposits, 2); ?></p>
        </div>
        <!-- Total User Balances Card -->
        <div class="p-6 bg-blue-800/50 rounded-lg">
            <h3 class="text-sm font-medium text-blue-300 uppercase">Total User Balances</h3>
            <p class="mt-2 text-3xl font-bold text-white">$<?php echo number_format($total_user_balances, 2); ?></p>
        </div>
        <!-- Total Withdrawals Card -->
        <div class="p-6 bg-red-800/50 rounded-lg">
            <h3 class="text-sm font-medium text-red-300 uppercase">Total Withdrawals</h3>
            <p class="mt-2 text-3xl font-bold text-white">$<?php echo number_format($total_withdrawals, 2); ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Management Links -->
        <div>
            <h3 class="text-xl font-semibold mb-4">Management Tools</h3>
            <div class="space-y-4">
                <a href="manage_users.php" class="block p-4 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition">
                    <h4 class="font-semibold text-white">Manage Users</h4>
                    <p class="text-sm text-gray-400">View all users and edit their wallets.</p>
                </a>
                <a href="create_bet.php" class="block p-4 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition">
                    <h4 class="font-semibold text-white">Create New Bet</h4>
                    <p class="text-sm text-gray-400">Create a full event with options in one step.</p>
                </a>
                <a href="manage_events_v2.php" class="block p-4 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition">
                    <h4 class="font-semibold text-white">Manage All Events</h4>
                    <p class="text-sm text-gray-400">Edit, delete, and settle existing events.</p>
                </a>
                 <a href="manage_withdrawals.php" class="block p-4 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition">
                    <h4 class="font-semibold text-white">Approve Withdrawals</h4>
                    <p class="text-sm text-gray-400">View and manage pending withdrawal requests.</p>
                </a>
            </div>
        </div>
        
        <!-- Top Traders Leaderboard -->
        <div>
            <h3 class="text-xl font-semibold mb-4">Top Earning Traders</h3>
            <div class="bg-gray-900/50 rounded-lg p-4">
                <ul class="space-y-3">
                    <?php if (empty($top_traders)): ?>
                        <li class="text-gray-400">No winnings recorded yet.</li>
                    <?php else: ?>
                        <?php foreach ($top_traders as $index => $trader): ?>
                            <li class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <span class="text-lg font-bold text-yellow-400 mr-4"><?php echo $index + 1; ?>.</span>
                                    <span class="font-semibold text-white"><?php echo htmlspecialchars($trader['username']); ?></span>
                                </div>
                                <span class="font-mono text-green-400">$<?php echo number_format($trader['total_winnings'], 2); ?></span>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

</body>
</html>
