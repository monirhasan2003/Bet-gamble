<?php
require_once 'admin_header.php';

// Get the user ID from the URL, make sure it's a number
if (!isset($_GET['user_id']) || !is_numeric($_GET['user_id'])) {
    die("Error: Invalid User ID.");
}
$user_id_to_edit = intval($_GET['user_id']);

$error_message = '';
$success_message = '';

// Handle form submission to adjust the wallet
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['adjust_wallet'])) {
    $adjustment_amount = floatval($_POST['adjustment_amount']);
    $adjustment_reason = trim($_POST['adjustment_reason']);

    if ($adjustment_amount == 0 || empty($adjustment_reason)) {
        $error_message = "Adjustment amount cannot be zero and a reason is required.";
    } else {
        $conn->beginTransaction();
        try {
            // 1. Update the user's wallet balance
            $update_wallet_stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE user_id = ?");
            $update_wallet_stmt->execute([$adjustment_amount, $user_id_to_edit]);

            // 2. Log this manual adjustment in the transactions table
            $transaction_type = ($adjustment_amount > 0) ? 'bonus' : 'refund'; // Or 'manual_debit' etc.
            $insert_trans_stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, status, payment_method) VALUES (?, ?, ?, 'completed', ?)");
            $insert_trans_stmt->execute([$user_id_to_edit, $transaction_type, abs($adjustment_amount), 'Admin: ' . $adjustment_reason]);
            
            $conn->commit();
            $success_message = "User wallet adjusted successfully.";

        } catch (Exception $e) {
            $conn->rollBack();
            $error_message = "An error occurred: " . $e->getMessage();
        }
    }
}

// Fetch the current user data to display
$user_stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$user_stmt->execute([$user_id_to_edit]);
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("Error: User not found.");
}
?>

<div class="form-container !max-w-4xl">
    <a href="manage_users.php" class="text-yellow-400 hover:underline mb-4 inline-block">&larr; Back to User List</a>
    <h2 class="text-2xl font-bold mb-6">Edit User: <?php echo htmlspecialchars($user['username']); ?></h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- User Details Section -->
        <div class="p-6 bg-gray-900/50 rounded-lg">
            <h3 class="text-xl font-semibold mb-4">User Details</h3>
            <div class="space-y-2">
                <p><strong class="text-gray-400">User ID:</strong> #<?php echo $user['user_id']; ?></p>
                <p><strong class="text-gray-400">Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                <p><strong class="text-gray-400">Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong class="text-gray-400">Joined:</strong> <?php echo date("M j, Y", strtotime($user['created_at'])); ?></p>
                <p class="text-2xl mt-4"><strong class="text-gray-400">Current Balance:</strong> <span class="font-mono text-green-400">$<?php echo number_format($user['wallet_balance'], 2); ?></span></p>
            </div>
        </div>

        <!-- Wallet Adjustment Form -->
        <div class="p-6 bg-gray-900/50 rounded-lg">
            <h3 class="text-xl font-semibold mb-4">Adjust Wallet Balance</h3>
            <form action="edit_user.php?user_id=<?php echo $user_id_to_edit; ?>" method="post">
                <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
                <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>
                <div class="space-y-4">
                    <div>
                        <label for="adjustment_amount" class="block mb-2 text-sm font-medium text-gray-300">Adjustment Amount</label>
                        <input type="text" name="adjustment_amount" id="adjustment_amount" class="form-input" placeholder="e.g., 50.00 or -10.00" required>
                        <p class="text-xs text-gray-400 mt-1">Use a positive number to add funds (bonus) and a negative number to subtract funds.</p>
                    </div>
                    <div>
                        <label for="adjustment_reason" class="block mb-2 text-sm font-medium text-gray-300">Reason for Adjustment</label>
                        <input type="text" name="adjustment_reason" id="adjustment_reason" class="form-input" placeholder="e.g., Welcome Bonus" required>
                    </div>
                    <button type="submit" name="adjust_wallet" class="btn-gradient !w-auto px-8">Apply Adjustment</button>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
