<?php
require_once 'admin_header.php';

$error_message = '';
$success_message = '';

// Handle form submission to create the new event and its options
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_bet'])) {
    // Get event data
    $category_id = $_POST['category_id'];
    $question = trim($_POST['question']);
    $closes_at = trim($_POST['closes_at']);
    
    // Get options data (it will be an array)
    $option_names = $_POST['option_names'];
    $payouts = $_POST['payouts'];

    // Basic validation
    if (empty($category_id) || empty($question) || empty($closes_at) || empty($option_names) || count($option_names) < 2) {
        $error_message = "Category, Question, Closing Date, and at least two Options are required.";
    } else {
        $conn->beginTransaction();
        try {
            // 1. Insert the main event into the bet_events table
            $stmt = $conn->prepare("INSERT INTO bet_events (category_id, question, closes_at) VALUES (?, ?, ?)");
            $stmt->execute([$category_id, $question, $closes_at]);
            
            // 2. Get the ID of the event we just created
            $event_id = $conn->lastInsertId();

            // 3. Loop through the submitted options and insert them into the bet_options table
            $option_stmt = $conn->prepare("INSERT INTO bet_options (event_id, option_name, payout_multiplier) VALUES (?, ?, ?)");
            for ($i = 0; $i < count($option_names); $i++) {
                $name = trim($option_names[$i]);
                $payout = floatval($payouts[$i]);
                if (!empty($name) && $payout > 0) {
                    $option_stmt->execute([$event_id, $name, $payout]);
                }
            }

            $conn->commit();
            $success_message = "New bet event and its options were created successfully!";

        } catch (Exception $e) {
            $conn->rollBack();
            $error_message = "An error occurred: " . $e->getMessage();
        }
    }
}

// Fetch all categories for the dropdown menu
$categories = $conn->query("SELECT * FROM bet_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="form-container !max-w-4xl">
    <h2 class="text-2xl font-bold mb-6">Create New Bet (All-in-One)</h2>

    <form action="create_bet.php" method="post" class="p-6 bg-gray-900/50 rounded-lg">
        <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
        <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>

        <!-- Event Details Section -->
        <h3 class="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">1. Event Details</h3>
        <div class="space-y-4 mb-8">
            <div>
                <label for="category_id" class="block mb-2 text-sm font-medium text-gray-300">Category</label>
                <select name="category_id" id="category_id" class="form-input" required>
                    <option value="">-- Select a Category --</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category_id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="question" class="block mb-2 text-sm font-medium text-gray-300">Betting Question</label>
                <input type="text" name="question" id="question" class="form-input" placeholder="e.g., Who will win the next match?" required>
            </div>
            <div>
                <label for="closes_at" class="block mb-2 text-sm font-medium text-gray-300">Betting Closes On</label>
                <input type="datetime-local" name="closes_at" id="closes_at" class="form-input" required>
            </div>
        </div>

        <!-- Dynamic Options Section -->
        <h3 class="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">2. Betting Options</h3>
        <div id="options-container" class="space-y-4">
            <!-- JavaScript will add option fields here -->
        </div>
        <button type="button" id="add-option-btn" class="mt-4 text-green-400 hover:text-white font-bold py-2 px-4 rounded border border-green-400">
            + Add Option
        </button>
        
        <!-- Submit Button -->
        <div class="mt-8 border-t border-gray-700 pt-6">
            <button type="submit" name="create_bet" class="btn-gradient w-full md:w-auto px-12 py-3">Create Full Bet Event</button>
        </div>
    </form>
</div>

<!-- JAVASCRIPT for dynamic option fields -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const optionsContainer = document.getElementById('options-container');
        const addOptionBtn = document.getElementById('add-option-btn');
        let optionCount = 0;

        function addOptionField() {
            optionCount++;
            const newOptionDiv = document.createElement('div');
            newOptionDiv.classList.add('flex', 'items-center', 'space-x-4', 'option-row');
            
            newOptionDiv.innerHTML = `
                <div class="flex-grow">
                    <label class="hidden">Option Name</label>
                    <input type="text" name="option_names[]" class="form-input" placeholder="Option Name (e.g., Yes, No, Team A)" required>
                </div>
                <div class="w-1/4">
                    <label class="hidden">Payout</label>
                    <input type="text" name="payouts[]" class="form-input" placeholder="Payout (e.g., 1.85)" required>
                </div>
                <button type="button" class="remove-option-btn text-red-500 hover:text-white font-bold py-2 px-4 rounded border border-red-500">
                    &times;
                </button>
            `;
            optionsContainer.appendChild(newOptionDiv);
        }

        // Add the first two option fields automatically when the page loads
        addOptionField();
        addOptionField();

        // Add a new option field when the button is clicked
        addOptionBtn.addEventListener('click', addOptionField);

        // Handle removing an option field
        optionsContainer.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('remove-option-btn')) {
                // Prevent removing if it's one of the last two options
                if (optionsContainer.querySelectorAll('.option-row').length > 2) {
                    e.target.closest('.option-row').remove();
                } else {
                    alert('You must have at least two options.');
                }
            }
        });
    });
</script>

</body>
</html>
