<?php
require_once 'admin_header.php';

$error_message = '';
$success_message = '';

// --- HANDLE ALL FORM ACTIONS ---

// ADD a new notice
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_notice'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    if (empty($title) || empty($content)) {
        $error_message = "Title and Content are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO notices (title, content) VALUES (?, ?)");
        $stmt->execute([$title, $content]);
        $success_message = "Notice created successfully.";
    }
}

// DELETE a notice
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_notice'])) {
    $notice_id = intval($_POST['notice_id']);
    $stmt = $conn->prepare("DELETE FROM notices WHERE notice_id = ?");
    $stmt->execute([$notice_id]);
    $success_message = "Notice deleted successfully.";
}

// ACTIVATE a notice
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['activate_notice'])) {
    $notice_id = intval($_POST['notice_id']);
    $conn->beginTransaction();
    try {
        // First, deactivate all other notices
        $conn->query("UPDATE notices SET is_active = 0");
        // Then, activate the selected one
        $stmt = $conn->prepare("UPDATE notices SET is_active = 1 WHERE notice_id = ?");
        $stmt->execute([$notice_id]);
        $conn->commit();
        $success_message = "Notice activated successfully.";
    } catch (Exception $e) {
        $conn->rollBack();
        $error_message = "Failed to activate notice.";
    }
}

// DEACTIVATE a notice
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['deactivate_notice'])) {
    $notice_id = intval($_POST['notice_id']);
    $stmt = $conn->prepare("UPDATE notices SET is_active = 0 WHERE notice_id = ?");
    $stmt->execute([$notice_id]);
    $success_message = "Notice deactivated successfully.";
}


// Fetch all notices for display
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="form-container !max-w-5xl">
    <h2 class="text-2xl font-bold mb-6">Manage Notices & Popups</h2>

    <!-- Form to add a new notice -->
    <form action="manage_notices.php" method="post" class="mb-10 p-6 bg-gray-900/50 rounded-lg">
        <h3 class="text-xl font-semibold mb-4">Create New Notice</h3>
        <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
        <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>
        <div class="space-y-4">
            <input type="text" name="title" class="form-input" placeholder="Notice Title" required>
            <textarea name="content" rows="4" class="form-input" placeholder="Enter the notice content here..." required></textarea>
            <button type="submit" name="add_notice" class="btn-gradient !w-auto px-8">Create Notice</button>
        </div>
    </form>

    <!-- Table to display existing notices -->
    <h3 class="text-xl font-semibold mb-4">Existing Notices</h3>
    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Title</th>
                    <th class="p-4">Status</th>
                    <th class="p-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($notices)): ?>
                    <tr><td colspan="3" class="p-4 text-center text-gray-400">No notices found.</td></tr>
                <?php else: ?>
                    <?php foreach ($notices as $notice): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($notice['title']); ?></td>
                            <td class="p-4">
                                <?php if ($notice['is_active']): ?>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Active</span>
                                <?php else: ?>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-4 flex items-center justify-end space-x-4">
                                <?php if ($notice['is_active']): ?>
                                    <form action="manage_notices.php" method="post">
                                        <input type="hidden" name="notice_id" value="<?php echo $notice['notice_id']; ?>">
                                        <button type="submit" name="deactivate_notice" class="text-yellow-400 hover:underline font-bold">Deactivate</button>
                                    </form>
                                <?php else: ?>
                                    <form action="manage_notices.php" method="post">
                                        <input type="hidden" name="notice_id" value="<?php echo $notice['notice_id']; ?>">
                                        <button type="submit" name="activate_notice" class="text-green-400 hover:underline font-bold">Activate</button>
                                    </form>
                                <?php endif; ?>
                                <form action="manage_notices.php" method="post" onsubmit="return confirm('Are you sure you want to delete this notice?');">
                                    <input type="hidden" name="notice_id" value="<?php echo $notice['notice_id']; ?>">
                                    <button type="submit" name="delete_notice" class="text-red-500 hover:underline font-bold">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
