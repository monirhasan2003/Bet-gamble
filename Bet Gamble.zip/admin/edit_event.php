<?php
require_once 'admin_header.php'; // Include the header

// Get the event ID from the URL, make sure it's a number
if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    die("Error: Invalid Event ID.");
}
$event_id = intval($_GET['event_id']);

$error_message = '';
$success_message = '';

// Handle form submission to UPDATE the event
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_event'])) {
    $category_id = $_POST['category_id'];
    $question = trim($_POST['question']);
    $closes_at_str = trim($_POST['closes_at']);
    // Convert the datetime-local string to a format MySQL understands
    $closes_at = date('Y-m-d H:i:s', strtotime($closes_at_str));

    if (empty($category_id) || empty($question) || empty($closes_at)) {
        $error_message = "All fields are required.";
    } else {
        try {
            $stmt = $conn->prepare("UPDATE bet_events SET category_id = ?, question = ?, closes_at = ? WHERE event_id = ?");
            $stmt->execute([$category_id, $question, $closes_at, $event_id]);
            $success_message = "Event updated successfully!";
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch the current event data to pre-fill the form
$event_stmt = $conn->prepare("SELECT * FROM bet_events WHERE event_id = ?");
$event_stmt->execute([$event_id]);
$event = $event_stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
    die("Error: Event not found.");
}

// Fetch all categories for the dropdown menu
$categories = $conn->query("SELECT * FROM bet_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

?>
<div class="form-container !max-w-5xl">
    <a href="manage_events_v2.php" class="text-yellow-400 hover:underline mb-4 inline-block">&larr; Back to All Events</a>
    <h2 class="text-2xl font-bold mb-6">Edit Event</h2>

    <!-- Form to edit the event -->
    <form action="edit_event.php?event_id=<?php echo $event_id; ?>" method="post" class="p-6 bg-gray-900/50 rounded-lg">
        <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
        <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>

        <div class="space-y-4">
            <div>
                <label for="category_id" class="block mb-2 text-sm font-medium text-gray-300">Category</label>
                <select name="category_id" id="category_id" class="form-input" required>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category_id']; ?>" <?php if ($event['category_id'] == $category['category_id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="question" class="block mb-2 text-sm font-medium text-gray-300">Betting Question</label>
                <input type="text" name="question" id="question" class="form-input" value="<?php echo htmlspecialchars($event['question']); ?>" required>
            </div>
            <div>
                <label for="closes_at" class="block mb-2 text-sm font-medium text-gray-300">Betting Closes On</label>
                <!-- To pre-fill datetime-local, the format must be Y-m-d\TH:i -->
                <input type="datetime-local" name="closes_at" id="closes_at" class="form-input" value="<?php echo date('Y-m-d\TH:i', strtotime($event['closes_at'])); ?>" required>
            </div>
            <button type="submit" name="update_event" class="btn-gradient !w-auto px-8">Save Changes</button>
        </div>
    </form>
</div>

</body>
</html>
