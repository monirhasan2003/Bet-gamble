<?php
require_once 'admin_header.php'; // Include the header

$error_message = '';
$success_message = '';

// Handle form submission for adding a new category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);

    if (empty($name)) {
        $error_message = "Category name is required.";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO bet_categories (name, description) VALUES (:name, :description)");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':description', $description);
            $stmt->execute();
            $success_message = "Category '$name' added successfully!";
        } catch (PDOException $e) {
            // Check for duplicate entry error
            if ($e->getCode() == 23000) {
                $error_message = "Category name already exists.";
            } else {
                $error_message = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Fetch all existing categories to display them
$categories_stmt = $conn->query("SELECT * FROM bet_categories ORDER BY name ASC");
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<div class="form-container !max-w-4xl">
    <h2 class="text-2xl font-bold mb-6">Manage Betting Categories</h2>

    <!-- Form to add a new category -->
    <form action="manage_categories.php" method="post" class="mb-10 p-6 bg-gray-900/50 rounded-lg">
        <h3 class="text-xl font-semibold mb-4">Add New Category</h3>

        <?php if(!empty($error_message)): ?>
            <div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if(!empty($success_message)): ?>
            <div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="space-y-4">
            <input type="text" name="name" class="form-input" placeholder="Category Name (e.g., Sports)" required>
            <textarea name="description" class="form-input" placeholder="Brief description (optional)"></textarea>
            <button type="submit" name="add_category" class="btn-gradient !w-auto px-8">Add Category</button>
        </div>
    </form>

    <!-- Table to display existing categories -->
    <h3 class="text-xl font-semibold mb-4">Existing Categories</h3>
    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Name</th>
                    <th class="p-4">Description</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($categories)): ?>
                    <tr>
                        <td colspan="2" class="p-4 text-center text-gray-400">No categories found. Add one above!</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($categories as $category): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($category['name']); ?></td>
                            <td class="p-4 text-gray-300"><?php echo htmlspecialchars($category['description']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php // We will add a footer file later ?>
</body>
</html>