<?php
require_once 'admin_header.php'; // Include the header

$error_message = '';
$success_message = '';

// Handle DELETE request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_event'])) {
    $event_id_to_delete = intval($_POST['event_id']);
    $conn->beginTransaction();
    try {
        $bets_to_delete_stmt = $conn->prepare("SELECT bet_id FROM user_bets WHERE event_id = ?");
        $bets_to_delete_stmt->execute([$event_id_to_delete]);
        $bet_ids = $bets_to_delete_stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($bet_ids)) {
            $placeholders = implode(',', array_fill(0, count($bet_ids), '?'));
            $delete_trans_stmt = $conn->prepare("DELETE FROM transactions WHERE related_bet_id IN ($placeholders)");
            $delete_trans_stmt->execute($bet_ids);
        }
        $delete_bets_stmt = $conn->prepare("DELETE FROM user_bets WHERE event_id = ?");
        $delete_bets_stmt->execute([$event_id_to_delete]);
        $delete_options_stmt = $conn->prepare("DELETE FROM bet_options WHERE event_id = ?");
        $delete_options_stmt->execute([$event_id_to_delete]);
        $delete_event_stmt = $conn->prepare("DELETE FROM bet_events WHERE event_id = ?");
        $delete_event_stmt->execute([$event_id_to_delete]);
        $conn->commit();
        $success_message = "Event and all associated data have been deleted successfully.";
    } catch (Exception $e) {
        $conn->rollBack();
        $error_message = "A critical error occurred during deletion. Error: " . $e->getMessage();
    }
}

// Handle ADD request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_event'])) {
    $category_id = $_POST['category_id'];
    $question = trim($_POST['question']);
    $closes_at = trim($_POST['closes_at']);
    if (empty($category_id) || empty($question) || empty($closes_at)) {
        $error_message = "All fields are required.";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO bet_events (category_id, question, closes_at) VALUES (:category_id, :question, :closes_at)");
            $stmt->execute(['category_id' => $category_id, 'question' => $question, 'closes_at' => $closes_at]);
            $success_message = "Event added successfully!";
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch data for display
$categories = $conn->query("SELECT * FROM bet_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$events = $conn->query("
    SELECT be.*, bc.name AS category_name 
    FROM bet_events AS be
    JOIN bet_categories AS bc ON be.category_id = bc.category_id
    ORDER BY be.event_id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="form-container !max-w-5xl">
    <h2 class="text-2xl font-bold mb-6">Manage Betting Events</h2>

    <!-- Add New Event Form -->
    <form action="manage_events_v2.php" method="post" class="mb-10 p-6 bg-gray-900/50 rounded-lg">
        <h3 class="text-xl font-semibold mb-4">Add New Event</h3>
        <?php if(!empty($error_message)): ?><div class="alert-box alert-error mb-4"><?php echo $error_message; ?></div><?php endif; ?>
        <?php if(!empty($success_message)): ?><div class="alert-box alert-success mb-4"><?php echo $success_message; ?></div><?php endif; ?>
        <div class="space-y-4">
            <div>
                <label for="category_id" class="block mb-2 text-sm font-medium text-gray-300">Category</label>
                <select name="category_id" id="category_id" class="form-input" required>
                    <option value="">-- Select a Category --</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category_id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="question" class="block mb-2 text-sm font-medium text-gray-300">Betting Question</label>
                <input type="text" name="question" id="question" class="form-input" placeholder="e.g., Who will win the 2026 Best Picture Oscar?" required>
            </div>
            <div>
                <label for="closes_at" class="block mb-2 text-sm font-medium text-gray-300">Betting Closes On</label>
                <input type="datetime-local" name="closes_at" id="closes_at" class="form-input" required>
            </div>
            <button type="submit" name="add_event" class="btn-gradient !w-auto px-8">Add Event</button>
        </div>
    </form>

    <!-- Existing Events Table -->
    <h3 class="text-xl font-semibold mb-4">Existing Events</h3>
    <div class="bg-gray-900/50 rounded-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-800/70">
                <tr>
                    <th class="p-4">Question</th>
                    <th class="p-4">Category</th>
                    <th class="p-4">Closes At</th>
                    <th class="p-4">Status</th>
                    <th class="p-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($events)): ?>
                    <tr><td colspan="5" class="p-4 text-center text-gray-400">No events found.</td></tr>
                <?php else: ?>
                    <?php foreach ($events as $event): ?>
                        <tr class="border-t border-gray-700">
                            <td class="p-4 font-semibold"><?php echo htmlspecialchars($event['question']); ?></td>
                            <td class="p-4"><?php echo htmlspecialchars($event['category_name']); ?></td>
                            <td class="p-4"><?php echo date("M j, Y, g:i a", strtotime($event['closes_at'])); ?></td>
                            <td class="p-4 uppercase font-bold text-xs"><?php echo htmlspecialchars($event['status']); ?></td>
                            <td class="p-4 flex items-center space-x-4">
                                <a href="edit_event.php?event_id=<?php echo $event['event_id']; ?>" class="font-bold text-blue-400 hover:underline">
                                    Edit
                                </a>
                                <a href="manage_options.php?event_id=<?php echo $event['event_id']; ?>" class="font-bold text-yellow-400 hover:underline">
                                    Options
                                </a>
                                <form action="manage_events_v2.php" method="post" onsubmit="return confirm('Are you sure you want to permanently delete this event and all associated bets? This cannot be undone.');">
                                    <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                                    <button type="submit" name="delete_event" class="text-red-500 hover:underline font-bold">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
